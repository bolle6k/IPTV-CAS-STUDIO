import os
import uuid
import datetime
from flask import Flask, request, render_template_string, redirect, url_for, flash
import config
from db_helper import DBHelper

app = Flask(__name__)
app.secret_key = config.MASTER_KEY

db = DBHelper(config.DB_PATH)

SELF_SERVICE_TEMPLATE = '''
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<title>Self-Service-Portal</title>
</head>
<body>
<h1>Self-Service-Portal</h1>

{% with messages = get_flashed_messages(with_categories=true) %}
  {% if messages %}
    <ul>
    {% for category, message in messages %}
      <li style="color: {% if category == 'error' %}red{% else %}green{% endif %}">{{ message }}</li>
    {% endfor %}
    </ul>
  {% endif %}
{% endwith %}

{% if user %}
  <p><b>Benutzername:</b> {{ user.username }}</p>
  <p><b>HWID:</b> {{ user.hwid }}</p>
  <p><b>Bestes aktives Paket:</b> {{ user.paket }}</p>

  {% if subscription %}
    <p><b>Abo gültig bis:</b> {{ subscription.end_date }}</p>
    <p><b>Restlaufzeit:</b> <span id="remaining-days"></span> Tage</p>
  {% else %}
    <p><i>Kein aktives Abo</i></p>
  {% endif %}

  <p><b>Token:</b> {{ user.token }}</p>
  <p><b>Email:</b> {{ user.email }}</p>

  <form method="post" action="{{ url_for('renew_token') }}">
    <input type="hidden" name="username" value="{{ user.username }}">
    <button type="submit">Token erneuern</button>
  </form>

  <h3>Paket buchen / verlängern</h3>
  <form method="post" action="{{ url_for('subscribe') }}">
    <input type="hidden" name="username" value="{{ user.username }}">
    <label for="paket">Paket:</label>
    <select name="paket" id="paket" required>
      {% for p in prices.keys() %}
        <option value="{{ p }}" {% if p == user.paket %}selected{% endif %}>{{ p }}</option>
      {% endfor %}
    </select>
    <label for="zyklus">Laufzeit:</label>
    <select name="zyklus" id="zyklus" required>
      <option value="1m">1 Monat - {{ prices[user.paket]['1m'] }}€</option>
      <option value="6m">6 Monate - {{ prices[user.paket]['6m'] }}€</option>
      <option value="12m">1 Jahr - {{ prices[user.paket]['12m'] }}€</option>
    </select>
    <button type="submit">Buchen / Verlängern</button>
  </form>

  <h3>Abo kündigen</h3>
  <form method="post" action="{{ url_for('cancel') }}">
    <input type="hidden" name="username" value="{{ user.username }}">
    <button type="submit" style="color:red;">Abo kündigen</button>
  </form>

{% else %}
  <form method="post" action="{{ url_for('login') }}">
    <label>Token: <input name="token" required></label>
    <button type="submit">Anmelden</button>
  </form>
  {% if error %}
    <p style="color:red;">{{ error }}</p>
  {% endif %}
{% endif %}

<script>
const prices = {{ prices | tojson }};
const paketSelect = document.getElementById('paket');
const zyklusSelect = document.getElementById('zyklus');

function updatePrices() {
  const paket = paketSelect.value;
  const zyklusOptions = {
    '1m': `1 Monat - ${prices[paket]['1m']}€`,
    '6m': `6 Monate - ${prices[paket]['6m']}€`,
    '12m': `1 Jahr - ${prices[paket]['12m']}€`
  };

  for (let option of zyklusSelect.options) {
    option.text = zyklusOptions[option.value];
  }
}

function showRemainingDays() {
  const endDateStr = "{{ subscription.end_date if subscription else '' }}";
  if (!endDateStr) {
    document.getElementById('remaining-days').innerText = '0';
    return;
  }
  const endDate = new Date(endDateStr);
  const now = new Date();
  const diffTime = endDate - now;
  const diffDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
  document.getElementById('remaining-days').innerText = diffDays;
}

if(paketSelect && zyklusSelect) {
  paketSelect.addEventListener('change', updatePrices);
  updatePrices();
}

showRemainingDays();
</script>
</body>
</html>
'''

def generate_new_ecm_key():
    return os.urandom(16).hex()

def calculate_valid_until(abo_end_date):
    valid_until_date = datetime.datetime.fromisoformat(abo_end_date) + datetime.timedelta(days=1)
    return valid_until_date.isoformat()

@app.route('/selfservice', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        token = request.form.get('token', '').strip()
        if not token:
            return render_template_string(SELF_SERVICE_TEMPLATE, user=None, error="Bitte Token eingeben", prices=config.PRICES)

        user_data = db.get_user_by_token(token)
        if not user_data:
            return render_template_string(SELF_SERVICE_TEMPLATE, user=None, error="Ungültiger Token", prices=config.PRICES)

        user = {
            'username': user_data[0],
            'hwid': user_data[1],
            'paket': user_data[2],
            'token': user_data[3],
            'email': user_data[4]
        }

        best_paket = db.get_best_active_package(user['username'])
        user['paket'] = best_paket

        subscription = db.get_active_subscription(user['username'])
        if subscription:
            subscription = {
                'id': subscription[0],
                'username': subscription[1],
                'paket': subscription[2],
                'start_date': subscription[3],
                'end_date': subscription[4],
                'active': subscription[5]
            }
        return render_template_string(SELF_SERVICE_TEMPLATE, user=user, subscription=subscription, error=None, prices=config.PRICES)

    return render_template_string(SELF_SERVICE_TEMPLATE, user=None, error=None, prices=config.PRICES)

@app.route('/selfservice/renew_token', methods=['POST'])
def renew_token():
    username = request.form.get('username', '')
    user = db.get_user_by_username(username)
    if not user:
        flash("Benutzer nicht gefunden", "error")
        return redirect(url_for('login'))

    new_token = uuid.uuid4().hex[:16]
    db.update_user_token(username, new_token)
    flash("Token erfolgreich erneuert", "success")
    return redirect(url_for('login') + f"?token={new_token}")

@app.route('/selfservice/subscribe', methods=['POST'])
def subscribe():
    username = request.form.get('username')
    paket = request.form.get('paket')
    zyklus = request.form.get('zyklus')
    if not username or not paket or zyklus not in ('1m', '6m', '12m'):
        flash("Ungültige Eingaben", "error")
        return redirect(url_for('login'))

    today = datetime.datetime.utcnow().date()
    active_sub = db.get_active_subscription(username)

    if active_sub and datetime.datetime.fromisoformat(active_sub[4]).date() >= today:
        end_date = datetime.datetime.fromisoformat(active_sub[4]).date()
    else:
        end_date = today

    if zyklus == '1m':
        new_end = end_date + datetime.timedelta(days=30)
    elif zyklus == '6m':
        new_end = end_date + datetime.timedelta(days=183)
    else:
        new_end = end_date + datetime.timedelta(days=365)

    db.add_subscription(username, paket, today.isoformat(), new_end.isoformat())

    new_key = generate_new_ecm_key()
    valid_until = calculate_valid_until(new_end.isoformat())
    db.store_key(new_key, valid_until, username, paket)

    flash(f"Paket {paket} gebucht bis {new_end.isoformat()} und neuer Schlüssel erzeugt.", "success")
    return redirect(url_for('login') + f"?token={db.get_token_by_username(username)}")

@app.route('/selfservice/cancel', methods=['POST'])
def cancel():
    username = request.form.get('username')
    if not username:
        flash("Benutzername fehlt", "error")
        return redirect(url_for('login'))

    db.cancel_subscription(username)
    flash("Abo gekündigt", "success")
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT_SELF_SERVICE, debug=True)
